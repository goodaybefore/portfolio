-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: my_trip_site
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `me_id` varchar(20) NOT NULL,
  `me_pw` varchar(255) NOT NULL,
  `me_name` varchar(10) NOT NULL,
  `me_gender` varchar(10) NOT NULL,
  `me_phone` varchar(13) NOT NULL,
  `me_email` varchar(50) NOT NULL,
  `me_birth` date DEFAULT NULL,
  `me_del` varchar(2) NOT NULL DEFAULT 'N',
  `me_nickname` varchar(20) DEFAULT NULL,
  `me_photo` varchar(255) DEFAULT NULL,
  `me_ori_photo_name` varchar(100) DEFAULT NULL,
  `me_gr_name` varchar(10) NOT NULL,
  `me_intro` varchar(140) DEFAULT NULL,
  `me_membership` varchar(2) DEFAULT 'N',
  `me_membership_lastday` datetime DEFAULT NULL,
  `me_op_name` varchar(10) NOT NULL,
  `me_last_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `me_attend_num` int DEFAULT '1',
  PRIMARY KEY (`me_id`),
  KEY `FK_grade_TO_member_1` (`me_gr_name`),
  KEY `me_op_name_idx` (`me_op_name`),
  CONSTRAINT `FK_opne_range_TO_member_1` FOREIGN KEY (`me_op_name`) REFERENCES `open_range` (`op_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES ('asdf','$2a$10$Z4kqqHd7jKzwuoX5.jIBW.LDKiknyVntrglAOpB9LYrxMnAww6lQO','asdf','male','010-7777-3322','goodaybefore@gmail.com','2022-01-01','N','asdf',NULL,NULL,'트립매니저',NULL,'N',NULL,'전체공개','2022-02-22 11:00:51',1),('qeasd','$2a$10$kEi5Ztn3aTReeqsQxhlxC.cHsJpRMAhgsH3UIwLuRu5gkNIWAYJXC','qeasd1','female','010-7894-6514','tvxq_net@naver.com',NULL,'N',NULL,NULL,NULL,'트립비기너',NULL,'N',NULL,'전체공개','2022-04-16 17:02:26',1),('qwer','$2a$10$rL4jdTwlWqI.jRnCMOJoVOUN11IBZP2zbBz2K3ATo2fjujSOnRMlO','qwerty','male','010-6325-5721','goodaybefore@gmail.com','2022-01-01','N','qwer','/qwer/ca505e30-ac0d-48c2-8c13-e443f79fe404_IMG_1958.JPEG',NULL,'트립비기너','소개합니다~','N',NULL,'전체공개','2022-02-22 11:00:40',1),('tsj02313','$2a$10$qEns3EwHvkzM7VZr9Y6bteuZT77I4P1Obt9Et2ahf7vBpQCKqm/YG','권나영','female','010-1111-1111','skdudzofl123@gmail.com','1995-04-25','N','날용','/tsj02313/fcff67e5-015b-4299-a6ef-4a9eb114d8fd_위풍당당.png',NULL,'트립비기너','올해엔 여행 많이 다녀야지!','N',NULL,'전체공개','2022-04-16 21:25:03',1),('zxcv','$2a$10$6SpsRm9/aMfbAvlct7ICEOBwb0S8aYxERFsMvr8YO2Hf4CLzI.J0m','zxcvb','female','010-9575-7782','goodaybefore@gmail.com','2022-01-04','N','zxcvy22','/zxcv/319c681c-fd90-453c-b7ad-b13f03781161_위풍당당.png',NULL,'트립비기너','','N',NULL,'전체공개','2022-02-23 17:46:56',1);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-18  2:02:17

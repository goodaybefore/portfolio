$(function(){
	$('.btn-write').click(function(){
		
	});
	$('.btn33').click(function(){
		
	})
});
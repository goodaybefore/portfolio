package kr.green.mytrip.vo;

import lombok.Data;

@Data
public class SmallCategoryVO {
	private int sc_num;
	private int sc_mc_num;
	private String sc_name;

}

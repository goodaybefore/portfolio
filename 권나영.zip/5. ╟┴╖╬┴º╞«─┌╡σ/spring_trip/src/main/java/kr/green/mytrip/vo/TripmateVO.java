package kr.green.mytrip.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TripmateVO {
	private int tm_num;
	private String tm_me_id;
	private String tm_mate_id;

}

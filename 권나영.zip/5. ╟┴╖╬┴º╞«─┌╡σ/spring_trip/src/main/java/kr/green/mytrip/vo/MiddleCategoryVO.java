package kr.green.mytrip.vo;

import lombok.Data;

@Data
public class MiddleCategoryVO {
	private int mc_num;
	private int mc_lc_num;
	private String mc_name;
}
